/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

# ------------------------------------------------------------
# SCHEMA DUMP FOR TABLE: projects
# ------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `projects` (
  `proj_no` int NOT NULL AUTO_INCREMENT,
  `proj_name` varchar(255) DEFAULT NULL,
  `starting_date` date DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  PRIMARY KEY (`proj_no`)
) ENGINE = InnoDB AUTO_INCREMENT = 30011 DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci;

# ------------------------------------------------------------
# DATA DUMP FOR TABLE: projects
# ------------------------------------------------------------

INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30001, 'Gallius', '2015-12-05', '2015-12-30');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30002, 'Halogian', '2016-01-01', '2016-01-15');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30003, 'Jessa', '2016-02-20', '2016-02-27');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30004, 'Ponius', '2016-03-12', '2016-03-23');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30005, 'Ringer', '2016-05-21', '2016-05-30');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30006, 'Wilmes', '2017-06-30', '2017-07-04');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30007, 'Omous', '2017-08-15', '2017-08-31');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30008, 'Dromide', '2018-06-19', '2018-07-07');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30009, 'Cades', '2018-11-16', '2018-11-22');
INSERT INTO
  `projects` (
    `proj_no`,
    `proj_name`,
    `starting_date`,
    `ending_date`
  )
VALUES
  (30010, 'Arvek', '2019-11-30', '2019-12-09');

/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
